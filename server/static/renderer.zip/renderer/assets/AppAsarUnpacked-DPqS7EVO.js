import { r as reactive, c as createElementBlock, a as createBaseVNode, t as toDisplayString, b as createCommentVNode, F as Fragment, o as openBlock } from "./index-BTdkU4J8.js";
const _hoisted_1 = /* @__PURE__ */ createBaseVNode("h1", null, "app.asar.unpacked 更新", -1);
const _hoisted_2 = /* @__PURE__ */ createBaseVNode("h1", { style: { "color": "red" } }, "我已经更新了 - 分离打包renderer进程", -1);
const _sfc_main = {
  __name: "AppAsarUnpacked",
  setup(__props) {
    const info = reactive({
      version: window.api.packageJson.version,
      serverVersion: "",
      isNeedUpdate: false
    });
    (async function getVersion() {
      const res = await fetch("http://localhost:8080/api/version");
      const data = await res.json();
      info.serverVersion = data.version;
      if (data.version !== info.version) {
        info.isNeedUpdate = true;
      }
    })();
    const handleUpdate = async () => {
      const response = await fetch("http://localhost:8080/renderer.zip");
      const blob = await response.blob();
      const buffer = await new Response(blob).arrayBuffer();
      window.api.updateAppAsarUnpacked(buffer);
    };
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        _hoisted_1,
        _hoisted_2,
        createBaseVNode("div", null, "当前版本：" + toDisplayString(info.version), 1),
        createBaseVNode("div", null, "服务器版本：" + toDisplayString(info.serverVersion), 1),
        info.isNeedUpdate ? (openBlock(), createElementBlock("button", {
          key: 0,
          onClick: handleUpdate
        }, "更新")) : createCommentVNode("", true)
      ], 64);
    };
  }
};
export {
  _sfc_main as default
};
